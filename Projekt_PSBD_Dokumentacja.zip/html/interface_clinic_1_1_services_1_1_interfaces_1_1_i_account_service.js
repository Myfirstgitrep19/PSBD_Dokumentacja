var interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service =
[
    [ "Login", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service.html#a41c663727269f0483435d3e9b99d7bb0", null ],
    [ "Logout", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service.html#af03cac387f40a8ee372cd3af9cd6e7f5", null ],
    [ "RegisterNewUser", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service.html#a152fcc4e6dca0974c32dd0f6abbbf563", null ]
];