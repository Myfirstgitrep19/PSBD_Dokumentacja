var class_clinic_1_1_startup =
[
    [ "Startup", "class_clinic_1_1_startup.html#a8b80243797f178838e3606ee62089e0b", null ],
    [ "Configure", "class_clinic_1_1_startup.html#a5d645e6f089ffcfbcd70a17debc9f077", null ],
    [ "ConfigureServices", "class_clinic_1_1_startup.html#ab6d6cd9696a51f24858205cf79c4dfea", null ],
    [ "Configuration", "class_clinic_1_1_startup.html#ad24a4f727d4a66809c91c851d6a7b558", null ]
];