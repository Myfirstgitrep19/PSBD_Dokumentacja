var class_clinic_1_1_models_1_1_app_user =
[
    [ "Address", "class_clinic_1_1_models_1_1_app_user.html#a7b012f2d8ec301b47dfe5787e57de4c0", null ],
    [ "AddressId", "class_clinic_1_1_models_1_1_app_user.html#a1fb0384dc40a83be90a2329a47c14b0d", null ],
    [ "FirstName", "class_clinic_1_1_models_1_1_app_user.html#a2a254e5baa98d2672b527f42be8e9e9d", null ],
    [ "LastName", "class_clinic_1_1_models_1_1_app_user.html#aa2d5cbac7cce6ae31decee4591ac9edb", null ]
];