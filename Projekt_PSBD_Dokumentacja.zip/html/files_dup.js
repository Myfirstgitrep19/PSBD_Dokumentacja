var files_dup =
[
    [ "Clinic-master", "dir_8d012ff333eb4f47470b4f20e2cad511.html", "dir_8d012ff333eb4f47470b4f20e2cad511" ]
];