var dir_3eadfa80d8f7d7b8fcfb611bf060c796 =
[
    [ "20200527211632_init.cs", "20200527211632__init_8cs.html", [
      [ "init", "class_clinic_1_1_migrations_1_1init.html", "class_clinic_1_1_migrations_1_1init" ]
    ] ],
    [ "20200527211632_init.Designer.cs", "20200527211632__init_8_designer_8cs.html", [
      [ "init", "class_clinic_1_1_migrations_1_1init.html", "class_clinic_1_1_migrations_1_1init" ]
    ] ],
    [ "ApplicationDbContextModelSnapshot.cs", "_application_db_context_model_snapshot_8cs.html", [
      [ "ApplicationDbContextModelSnapshot", "class_clinic_1_1_migrations_1_1_application_db_context_model_snapshot.html", "class_clinic_1_1_migrations_1_1_application_db_context_model_snapshot" ]
    ] ]
];