var class_clinic_1_1_models_1_1_clinic =
[
    [ "Address", "class_clinic_1_1_models_1_1_clinic.html#ada281f002180f57c8dd871e6c3d63586", null ],
    [ "AddressId", "class_clinic_1_1_models_1_1_clinic.html#a37aec7bbc3faa45f10dacf746058bff4", null ],
    [ "Id", "class_clinic_1_1_models_1_1_clinic.html#a1b76f9bcc8265df9b5aabc2e2b8d9877", null ],
    [ "Name", "class_clinic_1_1_models_1_1_clinic.html#acda962ebac1ba1bb961f33046d75c50a", null ]
];