var dir_d88c97426e81549e65cc109dcfdcba84 =
[
    [ "ClinicIndexViewModel.cs", "_clinic_index_view_model_8cs.html", [
      [ "ClinicIndexViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_clinic_index_view_model.html", "class_clinic_1_1_view_models_1_1_clinic_1_1_clinic_index_view_model" ]
    ] ],
    [ "DoctorsViewModel.cs", "_doctors_view_model_8cs.html", [
      [ "DoctorsViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model.html", "class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model" ]
    ] ],
    [ "VisitsViewModel.cs", "_visits_view_model_8cs.html", [
      [ "VisitsViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model.html", "class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model" ]
    ] ]
];