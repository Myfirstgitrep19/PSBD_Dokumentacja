var class_clinic_1_1_services_1_1_clinic_service =
[
    [ "ClinicService", "class_clinic_1_1_services_1_1_clinic_service.html#af48df4285ab3f66d2d871e6e5a1dd118", null ],
    [ "BookVisit", "class_clinic_1_1_services_1_1_clinic_service.html#a923ba135d92bfe12337dd293b2c7f525", null ],
    [ "DeleteVisit", "class_clinic_1_1_services_1_1_clinic_service.html#ada632348848a9f02976474dd545bc4bd", null ],
    [ "GetClinicIndexViewModel", "class_clinic_1_1_services_1_1_clinic_service.html#a1bff9e2e12122480694938c7d5e9ed7d", null ],
    [ "GetDoctorsViewModel", "class_clinic_1_1_services_1_1_clinic_service.html#a455ff48e9ee395e8b99199bf4454f8e6", null ],
    [ "GetVisitsViewModel", "class_clinic_1_1_services_1_1_clinic_service.html#a0daeaabe267e35334837eeb239983915", null ],
    [ "_context", "class_clinic_1_1_services_1_1_clinic_service.html#ac64fc0704e492c365281cffc11ca3d8c", null ]
];