var dir_62406cfbe65953d2211e668891289d5b =
[
    [ "Interfaces", "dir_fc0e8ce851d32c7f265ae9813e1d230d.html", "dir_fc0e8ce851d32c7f265ae9813e1d230d" ],
    [ "ServiceResponses", "dir_dcfd38993d178f2b10963fe9b6cdc692.html", "dir_dcfd38993d178f2b10963fe9b6cdc692" ],
    [ "AccountService.cs", "_account_service_8cs.html", [
      [ "AccountService", "class_clinic_1_1_services_1_1_account_service.html", "class_clinic_1_1_services_1_1_account_service" ]
    ] ],
    [ "BaseService.cs", "_base_service_8cs.html", [
      [ "BaseService", "class_clinic_1_1_services_1_1_base_service.html", "class_clinic_1_1_services_1_1_base_service" ]
    ] ],
    [ "ClinicService.cs", "_clinic_service_8cs.html", [
      [ "ClinicService", "class_clinic_1_1_services_1_1_clinic_service.html", "class_clinic_1_1_services_1_1_clinic_service" ]
    ] ],
    [ "HomeService.cs", "_home_service_8cs.html", [
      [ "HomeService", "class_clinic_1_1_services_1_1_home_service.html", "class_clinic_1_1_services_1_1_home_service" ]
    ] ]
];