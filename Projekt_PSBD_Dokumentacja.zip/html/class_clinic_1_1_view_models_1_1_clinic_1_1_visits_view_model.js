var class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model =
[
    [ "DoctorId", "class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model.html#a7d9e25ef15bf91101543d61df59438b3", null ]
];