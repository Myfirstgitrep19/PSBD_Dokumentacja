var class_clinic_1_1_program =
[
    [ "CreateHostBuilder", "class_clinic_1_1_program.html#ae0e48daf90b34fbfe43058eaa13bdcbc", null ],
    [ "Main", "class_clinic_1_1_program.html#af0386c491db99252ce4b6efd833253af", null ]
];