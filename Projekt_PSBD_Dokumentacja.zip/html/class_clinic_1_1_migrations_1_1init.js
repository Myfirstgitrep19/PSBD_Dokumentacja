var class_clinic_1_1_migrations_1_1init =
[
    [ "BuildTargetModel", "class_clinic_1_1_migrations_1_1init.html#a350351a3f03356fa7d574aba247136f5", null ],
    [ "Down", "class_clinic_1_1_migrations_1_1init.html#a9a73038239d67fbe2bdbd16d9e1e4217", null ],
    [ "Up", "class_clinic_1_1_migrations_1_1init.html#a237658b709b805067797ec7df31db286", null ]
];