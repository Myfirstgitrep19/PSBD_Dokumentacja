var searchData=
[
  ['password_384',['Password',['../class_clinic_1_1_view_models_1_1_account_1_1_login_view_model.html#a13981859186eb21be9b8d7e7116237a8',1,'Clinic.ViewModels.Account.LoginViewModel.Password()'],['../class_clinic_1_1_view_models_1_1_account_1_1_register_view_model.html#a11a65fac26cba4703ffbdc41bd2f741d',1,'Clinic.ViewModels.Account.RegisterViewModel.Password()']]],
  ['patient_385',['Patient',['../class_clinic_1_1_models_1_1_visit.html#a1f3b3bd2fa00643429d6c9af2a9218e9',1,'Clinic::Models::Visit']]],
  ['patientid_386',['PatientId',['../class_clinic_1_1_models_1_1_visit.html#a198f6d36d4f85b3e54b51eb6ebccc2ab',1,'Clinic::Models::Visit']]]
];
