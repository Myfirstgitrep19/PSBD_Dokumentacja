var searchData=
[
  ['username_395',['UserName',['../class_clinic_1_1_view_models_1_1_account_1_1_register_view_model.html#ab71464f7a8d8b915a173aaa553392e29',1,'Clinic::ViewModels::Account::RegisterViewModel']]]
];
