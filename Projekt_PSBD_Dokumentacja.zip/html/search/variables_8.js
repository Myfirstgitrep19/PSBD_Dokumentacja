var searchData=
[
  ['liability_343',['LIABILITY',['../jquery_2_l_i_c_e_n_s_e_8txt.html#a30cee5511dfd3ad583865ab8a6c201fc',1,'LICENSE.txt']]],
  ['logger_344',['Logger',['../class_clinic_1_1_controllers_1_1_account_controller.html#ab452d14db4d0f3c9908dd460b9d1ebfb',1,'Clinic.Controllers.AccountController.Logger()'],['../class_clinic_1_1_services_1_1_base_service.html#a1ffc090c2adc9f67ba6e71ddd30c7ea3',1,'Clinic.Services.BaseService.Logger()']]]
];
