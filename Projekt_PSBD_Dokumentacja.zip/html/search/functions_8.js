var searchData=
[
  ['index_302',['Index',['../class_clinic_1_1_controllers_1_1_clinic_controller.html#a1b8d90d1fc0a4f62e14a8b2fefa1a475',1,'Clinic.Controllers.ClinicController.Index()'],['../class_clinic_1_1_controllers_1_1_home_controller.html#afd3fe97be6bff272ef23def30c6646f0',1,'Clinic.Controllers.HomeController.Index()']]]
];
