var searchData=
[
  ['_5faccountservice_323',['_accountService',['../class_clinic_1_1_controllers_1_1_account_controller.html#acb7599d47fba4dd845f402208caa4e50',1,'Clinic::Controllers::AccountController']]],
  ['_5fclinicservice_324',['_clinicService',['../class_clinic_1_1_controllers_1_1_clinic_controller.html#a09fa9e9fb858b6391a5c2fea826ecf48',1,'Clinic::Controllers::ClinicController']]],
  ['_5fcontext_325',['_context',['../class_clinic_1_1_services_1_1_clinic_service.html#ac64fc0704e492c365281cffc11ca3d8c',1,'Clinic::Services::ClinicService']]],
  ['_5fhomeservice_326',['_homeService',['../class_clinic_1_1_controllers_1_1_home_controller.html#a251f2bc77af713184c9673ab2e7dab35',1,'Clinic::Controllers::HomeController']]],
  ['_5flogger_327',['_logger',['../class_clinic_1_1_controllers_1_1_home_controller.html#acb5c9bcf6b2e6e5e164ac1831a2ec5fc',1,'Clinic::Controllers::HomeController']]],
  ['_5fspecializationnames_328',['_specializationNames',['../class_clinic_1_1_data_1_1_data_initialization.html#aa1397ef23b9e4006b3555eca3f54f938',1,'Clinic::Data::DataInitialization']]]
];
