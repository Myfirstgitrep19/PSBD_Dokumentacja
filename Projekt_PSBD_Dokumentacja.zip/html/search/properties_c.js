var searchData=
[
  ['specialization_389',['Specialization',['../class_clinic_1_1_models_1_1_doctor.html#ad46948dc213d68fd18af929ccc423909',1,'Clinic::Models::Doctor']]],
  ['specializationid_390',['SpecializationId',['../class_clinic_1_1_models_1_1_doctor.html#a513c8fdb2afc17d26fcc2359b2698670',1,'Clinic::Models::Doctor']]],
  ['specializations_391',['Specializations',['../class_clinic_1_1_data_1_1_application_db_context.html#a596dcbe9696818add2658f7d01c0a423',1,'Clinic::Data::ApplicationDbContext']]],
  ['street_392',['Street',['../class_clinic_1_1_models_1_1_address.html#a09bbe8414b1fbfe37ebcc661083522e0',1,'Clinic::Models::Address']]],
  ['success_393',['Success',['../class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a801e09bc305e8c6bd13f56f345474914',1,'Clinic::Services::ServiceResponses::ServiceResponse']]]
];
