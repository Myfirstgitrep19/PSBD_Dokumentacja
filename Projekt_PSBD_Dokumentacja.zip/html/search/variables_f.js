var searchData=
[
  ['use_358',['use',['../jquery_2_l_i_c_e_n_s_e_8txt.html#ab596569b4acf71d8d26515263afdb977',1,'LICENSE.txt']]],
  ['usermanager_359',['UserManager',['../class_clinic_1_1_controllers_1_1_base_controller.html#ad3f2178c335cebe721061cd75ba55edd',1,'Clinic.Controllers.BaseController.UserManager()'],['../class_clinic_1_1_data_1_1_data_initialization.html#a0a3523aab177567fe928a1cc0fd73518',1,'Clinic.Data.DataInitialization.UserManager()'],['../class_clinic_1_1_services_1_1_account_service.html#a4a6f695d8a440dd6614218058dc3e9d9',1,'Clinic.Services.AccountService.UserManager()']]],
  ['userrepository_360',['UserRepository',['../class_clinic_1_1_controllers_1_1_base_controller.html#ad65342375b8edec461002072a064d70a',1,'Clinic::Controllers::BaseController']]]
];
