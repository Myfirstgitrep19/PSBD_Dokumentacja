var searchData=
[
  ['version_180',['Version',['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#ab275d752056b1eb94e5942a9a32babda',1,'LICENSE.txt']]],
  ['visit_181',['Visit',['../class_clinic_1_1_models_1_1_visit.html',1,'Clinic::Models']]],
  ['visit_2ecs_182',['Visit.cs',['../_visit_8cs.html',1,'']]],
  ['visits_183',['Visits',['../class_clinic_1_1_data_1_1_application_db_context.html#aba1c87b9401c17fc7e530d1915565ab3',1,'Clinic.Data.ApplicationDbContext.Visits()'],['../class_clinic_1_1_view_models_1_1_home_1_1_my_visits_view_model.html#a1a4f089ca5432bf3e0df3962d536b0f4',1,'Clinic.ViewModels.Home.MyVisitsViewModel.Visits()'],['../class_clinic_1_1_controllers_1_1_clinic_controller.html#aa10ccf50e8cd2266b45d184316a1ff92',1,'Clinic.Controllers.ClinicController.Visits(int doctorId)'],['../class_clinic_1_1_controllers_1_1_clinic_controller.html#af2cd6c2d7f0d3c4f236bd6fbf544385a',1,'Clinic.Controllers.ClinicController.Visits(VisitsViewModel model)']]],
  ['visitsviewmodel_184',['VisitsViewModel',['../class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model.html',1,'Clinic::ViewModels::Clinic']]],
  ['visitsviewmodel_2ecs_185',['VisitsViewModel.cs',['../_visits_view_model_8cs.html',1,'']]]
];
