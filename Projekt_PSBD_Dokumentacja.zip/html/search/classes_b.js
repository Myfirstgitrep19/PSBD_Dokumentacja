var searchData=
[
  ['serviceresponse_216',['ServiceResponse',['../class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html',1,'Clinic::Services::ServiceResponses']]],
  ['specialization_217',['Specialization',['../class_clinic_1_1_models_1_1_specialization.html',1,'Clinic::Models']]],
  ['startup_218',['Startup',['../class_clinic_1_1_startup.html',1,'Clinic']]]
];
