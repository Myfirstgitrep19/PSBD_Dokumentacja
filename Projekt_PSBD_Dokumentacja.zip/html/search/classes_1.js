var searchData=
[
  ['basecontroller_195',['BaseController',['../class_clinic_1_1_controllers_1_1_base_controller.html',1,'Clinic::Controllers']]],
  ['baseservice_196',['BaseService',['../class_clinic_1_1_services_1_1_base_service.html',1,'Clinic::Services']]]
];
