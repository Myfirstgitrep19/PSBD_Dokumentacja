var searchData=
[
  ['basecontroller_25',['BaseController',['../class_clinic_1_1_controllers_1_1_base_controller.html',1,'Clinic.Controllers.BaseController'],['../class_clinic_1_1_controllers_1_1_base_controller.html#a706cc935efcd0a21a4b0ad7593dc8200',1,'Clinic.Controllers.BaseController.BaseController()']]],
  ['basecontroller_2ecs_26',['BaseController.cs',['../_base_controller_8cs.html',1,'']]],
  ['baseservice_27',['BaseService',['../class_clinic_1_1_services_1_1_base_service.html',1,'Clinic.Services.BaseService'],['../class_clinic_1_1_services_1_1_base_service.html#affe9c22cd28b590a8f939784dba80849',1,'Clinic.Services.BaseService.BaseService()']]],
  ['baseservice_2ecs_28',['BaseService.cs',['../_base_service_8cs.html',1,'']]],
  ['basis_29',['BASIS',['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#a7481bdf69521f23e12265ac712583b87',1,'LICENSE.txt']]],
  ['bookvisit_30',['BookVisit',['../class_clinic_1_1_services_1_1_clinic_service.html#a923ba135d92bfe12337dd293b2c7f525',1,'Clinic.Services.ClinicService.BookVisit()'],['../interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a9d8b8df2e183bf78ae097548923f388f',1,'Clinic.Services.Interfaces.IClinicService.BookVisit()']]],
  ['buildmodel_31',['BuildModel',['../class_clinic_1_1_migrations_1_1_application_db_context_model_snapshot.html#a54f949dbb42b171c373fe47868d396e0',1,'Clinic::Migrations::ApplicationDbContextModelSnapshot']]],
  ['buildtargetmodel_32',['BuildTargetModel',['../class_clinic_1_1_migrations_1_1init.html#a350351a3f03356fa7d574aba247136f5',1,'Clinic::Migrations::init']]]
];
