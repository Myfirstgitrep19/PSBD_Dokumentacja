var searchData=
[
  ['datainitialization_201',['DataInitialization',['../class_clinic_1_1_data_1_1_data_initialization.html',1,'Clinic::Data']]],
  ['doctor_202',['Doctor',['../class_clinic_1_1_models_1_1_doctor.html',1,'Clinic::Models']]],
  ['doctorsviewmodel_203',['DoctorsViewModel',['../class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model.html',1,'Clinic::ViewModels::Clinic']]]
];
