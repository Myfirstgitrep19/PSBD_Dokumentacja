var searchData=
[
  ['visit_220',['Visit',['../class_clinic_1_1_models_1_1_visit.html',1,'Clinic::Models']]],
  ['visitsviewmodel_221',['VisitsViewModel',['../class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model.html',1,'Clinic::ViewModels::Clinic']]]
];
