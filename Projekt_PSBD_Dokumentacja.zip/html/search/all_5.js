var searchData=
[
  ['data_69',['Data',['../class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a2f4eac15fbeb8dd2a2358d86fa9f8b34',1,'Clinic::Services::ServiceResponses::ServiceResponse']]],
  ['datainitialization_70',['DataInitialization',['../class_clinic_1_1_data_1_1_data_initialization.html',1,'Clinic.Data.DataInitialization'],['../class_clinic_1_1_data_1_1_data_initialization.html#a47971f2cfeba2bd37a69b82b6eccce12',1,'Clinic.Data.DataInitialization.DataInitialization()']]],
  ['datainitialization_2ecs_71',['DataInitialization.cs',['../_data_initialization_8cs.html',1,'']]],
  ['deletevisit_72',['DeleteVisit',['../class_clinic_1_1_controllers_1_1_clinic_controller.html#ad2190414262b48d4c38f49f08af301bb',1,'Clinic.Controllers.ClinicController.DeleteVisit()'],['../class_clinic_1_1_services_1_1_clinic_service.html#ada632348848a9f02976474dd545bc4bd',1,'Clinic.Services.ClinicService.DeleteVisit()'],['../interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a243b5ef6b67b6aeced1ed6d5a9045f0e',1,'Clinic.Services.Interfaces.IClinicService.DeleteVisit()']]],
  ['distribute_73',['distribute',['../jquery_2_l_i_c_e_n_s_e_8txt.html#aaf067a71f14d0ec45d339828ab97b21d',1,'LICENSE.txt']]],
  ['doctor_74',['Doctor',['../class_clinic_1_1_models_1_1_doctor.html',1,'Clinic.Models.Doctor'],['../class_clinic_1_1_models_1_1_visit.html#a7e700e9aa025872e89714a58e6cc98f3',1,'Clinic.Models.Visit.Doctor()']]],
  ['doctor_2ecs_75',['Doctor.cs',['../_doctor_8cs.html',1,'']]],
  ['doctorid_76',['DoctorId',['../class_clinic_1_1_models_1_1_visit.html#ab3e3984234964ea61552f72c9b25dec9',1,'Clinic.Models.Visit.DoctorId()'],['../class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model.html#a7d9e25ef15bf91101543d61df59438b3',1,'Clinic.ViewModels.Clinic.VisitsViewModel.DoctorId()']]],
  ['doctors_77',['Doctors',['../class_clinic_1_1_data_1_1_application_db_context.html#a5aad21c8d06f5347907068ba5d691cf1',1,'Clinic.Data.ApplicationDbContext.Doctors()'],['../class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model.html#af6799a68a776beefb796cfe49ad42fa4',1,'Clinic.ViewModels.Clinic.DoctorsViewModel.Doctors()'],['../class_clinic_1_1_controllers_1_1_clinic_controller.html#ace21087eb3ad8361c70e22eb53c35a0f',1,'Clinic.Controllers.ClinicController.Doctors()']]],
  ['doctorsviewmodel_78',['DoctorsViewModel',['../class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model.html',1,'Clinic::ViewModels::Clinic']]],
  ['doctorsviewmodel_2ecs_79',['DoctorsViewModel.cs',['../_doctors_view_model_8cs.html',1,'']]],
  ['down_80',['Down',['../class_clinic_1_1_migrations_1_1init.html#a9a73038239d67fbe2bdbd16d9e1e4217',1,'Clinic::Migrations::init']]]
];
