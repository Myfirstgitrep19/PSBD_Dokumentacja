var searchData=
[
  ['userrepository_219',['UserRepository',['../class_clinic_1_1_repositories_1_1_user_repository.html',1,'Clinic::Repositories']]]
];
