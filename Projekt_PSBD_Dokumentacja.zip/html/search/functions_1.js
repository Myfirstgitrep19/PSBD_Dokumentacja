var searchData=
[
  ['basecontroller_276',['BaseController',['../class_clinic_1_1_controllers_1_1_base_controller.html#a706cc935efcd0a21a4b0ad7593dc8200',1,'Clinic::Controllers::BaseController']]],
  ['baseservice_277',['BaseService',['../class_clinic_1_1_services_1_1_base_service.html#affe9c22cd28b590a8f939784dba80849',1,'Clinic::Services::BaseService']]],
  ['bookvisit_278',['BookVisit',['../class_clinic_1_1_services_1_1_clinic_service.html#a923ba135d92bfe12337dd293b2c7f525',1,'Clinic.Services.ClinicService.BookVisit()'],['../interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a9d8b8df2e183bf78ae097548923f388f',1,'Clinic.Services.Interfaces.IClinicService.BookVisit()']]],
  ['buildmodel_279',['BuildModel',['../class_clinic_1_1_migrations_1_1_application_db_context_model_snapshot.html#a54f949dbb42b171c373fe47868d396e0',1,'Clinic::Migrations::ApplicationDbContextModelSnapshot']]],
  ['buildtargetmodel_280',['BuildTargetModel',['../class_clinic_1_1_migrations_1_1init.html#a350351a3f03356fa7d574aba247136f5',1,'Clinic::Migrations::init']]]
];
