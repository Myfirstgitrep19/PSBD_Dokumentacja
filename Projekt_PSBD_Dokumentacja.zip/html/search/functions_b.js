var searchData=
[
  ['ok_307',['Ok',['../class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a1404eb72e0c2aa939afb50ae5421818c',1,'Clinic.Services.ServiceResponses.ServiceResponse.Ok(bool data=true, string message=&quot;&quot;)'],['../class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a4dc546c7ef1d3bd805aab5d8399d535b',1,'Clinic.Services.ServiceResponses.ServiceResponse.Ok(T data, string message=&quot;&quot;)']]],
  ['onmodelcreating_308',['OnModelCreating',['../class_clinic_1_1_data_1_1_application_db_context.html#a14131764165ab8ef2bb1c5091629b1bb',1,'Clinic::Data::ApplicationDbContext']]]
];
