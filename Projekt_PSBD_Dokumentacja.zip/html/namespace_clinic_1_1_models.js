var namespace_clinic_1_1_models =
[
    [ "Address", "class_clinic_1_1_models_1_1_address.html", "class_clinic_1_1_models_1_1_address" ],
    [ "AppRole", "class_clinic_1_1_models_1_1_app_role.html", null ],
    [ "AppUser", "class_clinic_1_1_models_1_1_app_user.html", "class_clinic_1_1_models_1_1_app_user" ],
    [ "Clinic", "class_clinic_1_1_models_1_1_clinic.html", "class_clinic_1_1_models_1_1_clinic" ],
    [ "Doctor", "class_clinic_1_1_models_1_1_doctor.html", "class_clinic_1_1_models_1_1_doctor" ],
    [ "Specialization", "class_clinic_1_1_models_1_1_specialization.html", "class_clinic_1_1_models_1_1_specialization" ],
    [ "Visit", "class_clinic_1_1_models_1_1_visit.html", "class_clinic_1_1_models_1_1_visit" ]
];