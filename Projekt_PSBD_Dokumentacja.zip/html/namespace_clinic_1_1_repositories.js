var namespace_clinic_1_1_repositories =
[
    [ "Interfaces", "namespace_clinic_1_1_repositories_1_1_interfaces.html", "namespace_clinic_1_1_repositories_1_1_interfaces" ],
    [ "UserRepository", "class_clinic_1_1_repositories_1_1_user_repository.html", "class_clinic_1_1_repositories_1_1_user_repository" ]
];