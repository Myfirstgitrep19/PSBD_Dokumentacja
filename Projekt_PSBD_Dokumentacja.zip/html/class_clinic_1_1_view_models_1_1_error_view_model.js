var class_clinic_1_1_view_models_1_1_error_view_model =
[
    [ "ShowRequestId", "class_clinic_1_1_view_models_1_1_error_view_model.html#a3b6535b49043d8276f0632471541c895", null ],
    [ "RequestId", "class_clinic_1_1_view_models_1_1_error_view_model.html#a6c546904606e0aa223c8eec3c7636bc7", null ]
];