var class_clinic_1_1_models_1_1_doctor =
[
    [ "Clinic", "class_clinic_1_1_models_1_1_doctor.html#a2477ac939e78f4ced7566aa585f47715", null ],
    [ "ClinicId", "class_clinic_1_1_models_1_1_doctor.html#a72068a2ec89c1584bd73419518311eb0", null ],
    [ "Id", "class_clinic_1_1_models_1_1_doctor.html#a06243832ca87a300be98cb4f3d76e1bf", null ],
    [ "Name", "class_clinic_1_1_models_1_1_doctor.html#afda6fc2027ae3856c0dea463025c5f7c", null ],
    [ "Specialization", "class_clinic_1_1_models_1_1_doctor.html#ad46948dc213d68fd18af929ccc423909", null ],
    [ "SpecializationId", "class_clinic_1_1_models_1_1_doctor.html#a513c8fdb2afc17d26fcc2359b2698670", null ]
];