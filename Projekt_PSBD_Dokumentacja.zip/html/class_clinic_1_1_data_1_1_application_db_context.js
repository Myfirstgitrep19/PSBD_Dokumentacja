var class_clinic_1_1_data_1_1_application_db_context =
[
    [ "ApplicationDbContext", "class_clinic_1_1_data_1_1_application_db_context.html#a99ba94467d14cffb751413bd311978b8", null ],
    [ "OnModelCreating", "class_clinic_1_1_data_1_1_application_db_context.html#a14131764165ab8ef2bb1c5091629b1bb", null ],
    [ "Addresses", "class_clinic_1_1_data_1_1_application_db_context.html#a80ee7614aa2b8e3a5d4f9a2905d53d44", null ],
    [ "Clinics", "class_clinic_1_1_data_1_1_application_db_context.html#acd8b6434295e30ee46f59565dae25ddf", null ],
    [ "Doctors", "class_clinic_1_1_data_1_1_application_db_context.html#a5aad21c8d06f5347907068ba5d691cf1", null ],
    [ "Specializations", "class_clinic_1_1_data_1_1_application_db_context.html#a596dcbe9696818add2658f7d01c0a423", null ],
    [ "Visits", "class_clinic_1_1_data_1_1_application_db_context.html#aba1c87b9401c17fc7e530d1915565ab3", null ]
];