var namespace_clinic_1_1_services =
[
    [ "Interfaces", "namespace_clinic_1_1_services_1_1_interfaces.html", "namespace_clinic_1_1_services_1_1_interfaces" ],
    [ "ServiceResponses", "namespace_clinic_1_1_services_1_1_service_responses.html", "namespace_clinic_1_1_services_1_1_service_responses" ],
    [ "AccountService", "class_clinic_1_1_services_1_1_account_service.html", "class_clinic_1_1_services_1_1_account_service" ],
    [ "BaseService", "class_clinic_1_1_services_1_1_base_service.html", "class_clinic_1_1_services_1_1_base_service" ],
    [ "ClinicService", "class_clinic_1_1_services_1_1_clinic_service.html", "class_clinic_1_1_services_1_1_clinic_service" ],
    [ "HomeService", "class_clinic_1_1_services_1_1_home_service.html", "class_clinic_1_1_services_1_1_home_service" ]
];