var interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service =
[
    [ "BookVisit", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a9d8b8df2e183bf78ae097548923f388f", null ],
    [ "DeleteVisit", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a243b5ef6b67b6aeced1ed6d5a9045f0e", null ],
    [ "GetClinicIndexViewModel", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a523733e098d14670fec3e2c1a2820cc2", null ],
    [ "GetDoctorsViewModel", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a8740234ccf99bcd8fe72c6353a80906a", null ],
    [ "GetVisitsViewModel", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a802bd7cd869df4ddb0bc86f4f69fb6f2", null ]
];