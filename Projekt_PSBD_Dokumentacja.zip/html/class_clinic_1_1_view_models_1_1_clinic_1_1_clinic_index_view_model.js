var class_clinic_1_1_view_models_1_1_clinic_1_1_clinic_index_view_model =
[
    [ "Clinics", "class_clinic_1_1_view_models_1_1_clinic_1_1_clinic_index_view_model.html#a12a311da86b7d77571c3e933bf3c72e0", null ]
];