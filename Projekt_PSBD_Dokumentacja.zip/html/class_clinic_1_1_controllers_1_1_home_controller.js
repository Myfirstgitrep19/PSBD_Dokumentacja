var class_clinic_1_1_controllers_1_1_home_controller =
[
    [ "HomeController", "class_clinic_1_1_controllers_1_1_home_controller.html#ae61b0a82aded5e0956028bd525378eb4", null ],
    [ "Error", "class_clinic_1_1_controllers_1_1_home_controller.html#a6fc471603477a12997a0cbcd7621f610", null ],
    [ "Index", "class_clinic_1_1_controllers_1_1_home_controller.html#afd3fe97be6bff272ef23def30c6646f0", null ],
    [ "MyVisits", "class_clinic_1_1_controllers_1_1_home_controller.html#ac4cb0b5bdefadf20ddf6090d5ebba1c4", null ],
    [ "Privacy", "class_clinic_1_1_controllers_1_1_home_controller.html#afd08a8155170fad68bed34a59977765a", null ],
    [ "_homeService", "class_clinic_1_1_controllers_1_1_home_controller.html#a251f2bc77af713184c9673ab2e7dab35", null ],
    [ "_logger", "class_clinic_1_1_controllers_1_1_home_controller.html#acb5c9bcf6b2e6e5e164ac1831a2ec5fc", null ]
];