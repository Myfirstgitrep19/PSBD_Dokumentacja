var interface_clinic_1_1_repositories_1_1_interfaces_1_1_i_user_repository =
[
    [ "GetUserById", "interface_clinic_1_1_repositories_1_1_interfaces_1_1_i_user_repository.html#a88e7a519c2f81574126947af463bdaa4", null ]
];