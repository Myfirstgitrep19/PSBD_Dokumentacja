var namespace_clinic_1_1_repositories_1_1_interfaces =
[
    [ "IUserRepository", "interface_clinic_1_1_repositories_1_1_interfaces_1_1_i_user_repository.html", "interface_clinic_1_1_repositories_1_1_interfaces_1_1_i_user_repository" ]
];