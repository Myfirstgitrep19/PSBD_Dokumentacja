var class_clinic_1_1_models_1_1_address =
[
    [ "City", "class_clinic_1_1_models_1_1_address.html#a7706056f0a11cf21e2015cfea4e975cb", null ],
    [ "Country", "class_clinic_1_1_models_1_1_address.html#a5b07a6a5493552af276a6b5d37a05153", null ],
    [ "HouseNumber", "class_clinic_1_1_models_1_1_address.html#a3a8c4d383eb0d835cac4ed320111e1ed", null ],
    [ "Id", "class_clinic_1_1_models_1_1_address.html#a8845b38fce0281020a466c8cc63da2ac", null ],
    [ "Street", "class_clinic_1_1_models_1_1_address.html#a09bbe8414b1fbfe37ebcc661083522e0", null ],
    [ "ZipCode", "class_clinic_1_1_models_1_1_address.html#a6175eff554362681f555f7a1012d3158", null ]
];