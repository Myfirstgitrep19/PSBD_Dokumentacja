var dir_3c2d042c98e0a7dcb0ea47adc99096b9 =
[
    [ "Controllers", "dir_111a0999b97614a781787bd3518c065b.html", "dir_111a0999b97614a781787bd3518c065b" ],
    [ "Data", "dir_f434ba72540700a58a186a8a1803d3f7.html", "dir_f434ba72540700a58a186a8a1803d3f7" ],
    [ "Migrations", "dir_3eadfa80d8f7d7b8fcfb611bf060c796.html", "dir_3eadfa80d8f7d7b8fcfb611bf060c796" ],
    [ "Models", "dir_1aa5d456c87b9f4a04a1e25b7c2a1db4.html", "dir_1aa5d456c87b9f4a04a1e25b7c2a1db4" ],
    [ "Repositories", "dir_01c93750b4c39c2d0b849550c85f6d44.html", "dir_01c93750b4c39c2d0b849550c85f6d44" ],
    [ "Services", "dir_62406cfbe65953d2211e668891289d5b.html", "dir_62406cfbe65953d2211e668891289d5b" ],
    [ "ViewModels", "dir_8c1e2ff552f2db7a1a146d02642c65ef.html", "dir_8c1e2ff552f2db7a1a146d02642c65ef" ],
    [ "wwwroot", "dir_cf318e8a3f1ec643afa65cf89110a766.html", "dir_cf318e8a3f1ec643afa65cf89110a766" ],
    [ "Program.cs", "_program_8cs.html", [
      [ "Program", "class_clinic_1_1_program.html", "class_clinic_1_1_program" ],
      [ "WebHostExtensions", "class_clinic_1_1_web_host_extensions.html", "class_clinic_1_1_web_host_extensions" ]
    ] ],
    [ "Startup.cs", "_startup_8cs.html", [
      [ "Startup", "class_clinic_1_1_startup.html", "class_clinic_1_1_startup" ]
    ] ]
];