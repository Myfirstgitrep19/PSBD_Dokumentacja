var class_clinic_1_1_services_1_1_service_responses_1_1_service_response =
[
    [ "ServiceResponse", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a670669e846d1a02fca1f71b0cba11dc2", null ],
    [ "Error", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a4e0aa9e47832d73fdd9ea97f7b4d5cbe", null ],
    [ "Ok", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a1404eb72e0c2aa939afb50ae5421818c", null ],
    [ "Ok", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a4dc546c7ef1d3bd805aab5d8399d535b", null ],
    [ "Data", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a2f4eac15fbeb8dd2a2358d86fa9f8b34", null ],
    [ "Message", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a257a3e8eebe574c4432318ceb1115b50", null ],
    [ "Success", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a801e09bc305e8c6bd13f56f345474914", null ]
];