var dir_1aa5d456c87b9f4a04a1e25b7c2a1db4 =
[
    [ "Address.cs", "_address_8cs.html", [
      [ "Address", "class_clinic_1_1_models_1_1_address.html", "class_clinic_1_1_models_1_1_address" ]
    ] ],
    [ "AppRole.cs", "_app_role_8cs.html", [
      [ "AppRole", "class_clinic_1_1_models_1_1_app_role.html", null ]
    ] ],
    [ "AppUser.cs", "_app_user_8cs.html", [
      [ "AppUser", "class_clinic_1_1_models_1_1_app_user.html", "class_clinic_1_1_models_1_1_app_user" ]
    ] ],
    [ "Clinic.cs", "_clinic_8cs.html", [
      [ "Clinic", "class_clinic_1_1_models_1_1_clinic.html", "class_clinic_1_1_models_1_1_clinic" ]
    ] ],
    [ "Doctor.cs", "_doctor_8cs.html", [
      [ "Doctor", "class_clinic_1_1_models_1_1_doctor.html", "class_clinic_1_1_models_1_1_doctor" ]
    ] ],
    [ "Specialization.cs", "_specialization_8cs.html", [
      [ "Specialization", "class_clinic_1_1_models_1_1_specialization.html", "class_clinic_1_1_models_1_1_specialization" ]
    ] ],
    [ "Visit.cs", "_visit_8cs.html", [
      [ "Visit", "class_clinic_1_1_models_1_1_visit.html", "class_clinic_1_1_models_1_1_visit" ]
    ] ]
];