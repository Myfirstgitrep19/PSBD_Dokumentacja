var interface_clinic_1_1_services_1_1_interfaces_1_1_i_home_service =
[
    [ "GetMyVisitsViewModel", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_home_service.html#af41034ec95cbccf114a8bd6a38063e31", null ]
];