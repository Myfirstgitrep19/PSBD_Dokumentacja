var class_clinic_1_1_controllers_1_1_base_controller =
[
    [ "BaseController", "class_clinic_1_1_controllers_1_1_base_controller.html#a706cc935efcd0a21a4b0ad7593dc8200", null ],
    [ "ErrorPage", "class_clinic_1_1_controllers_1_1_base_controller.html#ac34aedf287434cfcb6937063f68affc3", null ],
    [ "GetLoggedUser", "class_clinic_1_1_controllers_1_1_base_controller.html#a33f6ffc605e287befd609ce7d1e99b44", null ],
    [ "UserManager", "class_clinic_1_1_controllers_1_1_base_controller.html#ad3f2178c335cebe721061cd75ba55edd", null ],
    [ "UserRepository", "class_clinic_1_1_controllers_1_1_base_controller.html#ad65342375b8edec461002072a064d70a", null ]
];