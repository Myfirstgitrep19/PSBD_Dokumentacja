var namespace_clinic =
[
    [ "Controllers", "namespace_clinic_1_1_controllers.html", "namespace_clinic_1_1_controllers" ],
    [ "Data", "namespace_clinic_1_1_data.html", "namespace_clinic_1_1_data" ],
    [ "Migrations", "namespace_clinic_1_1_migrations.html", "namespace_clinic_1_1_migrations" ],
    [ "Models", "namespace_clinic_1_1_models.html", "namespace_clinic_1_1_models" ],
    [ "Repositories", "namespace_clinic_1_1_repositories.html", "namespace_clinic_1_1_repositories" ],
    [ "Services", "namespace_clinic_1_1_services.html", "namespace_clinic_1_1_services" ],
    [ "ViewModels", "namespace_clinic_1_1_view_models.html", "namespace_clinic_1_1_view_models" ],
    [ "Program", "class_clinic_1_1_program.html", "class_clinic_1_1_program" ],
    [ "Startup", "class_clinic_1_1_startup.html", "class_clinic_1_1_startup" ],
    [ "WebHostExtensions", "class_clinic_1_1_web_host_extensions.html", "class_clinic_1_1_web_host_extensions" ]
];