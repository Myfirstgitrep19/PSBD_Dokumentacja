var hierarchy =
[
    [ "Clinic.Models.Address", "class_clinic_1_1_models_1_1_address.html", null ],
    [ "Clinic.Services.BaseService", "class_clinic_1_1_services_1_1_base_service.html", [
      [ "Clinic.Services.AccountService", "class_clinic_1_1_services_1_1_account_service.html", null ],
      [ "Clinic.Services.ClinicService", "class_clinic_1_1_services_1_1_clinic_service.html", null ],
      [ "Clinic.Services.HomeService", "class_clinic_1_1_services_1_1_home_service.html", null ]
    ] ],
    [ "Clinic.Models.Clinic", "class_clinic_1_1_models_1_1_clinic.html", null ],
    [ "Clinic.ViewModels.Clinic.ClinicIndexViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_clinic_index_view_model.html", null ],
    [ "Controller", null, [
      [ "Clinic.Controllers.BaseController", "class_clinic_1_1_controllers_1_1_base_controller.html", [
        [ "Clinic.Controllers.AccountController", "class_clinic_1_1_controllers_1_1_account_controller.html", null ],
        [ "Clinic.Controllers.ClinicController", "class_clinic_1_1_controllers_1_1_clinic_controller.html", null ],
        [ "Clinic.Controllers.HomeController", "class_clinic_1_1_controllers_1_1_home_controller.html", null ]
      ] ]
    ] ],
    [ "Clinic.Data.DataInitialization", "class_clinic_1_1_data_1_1_data_initialization.html", null ],
    [ "Clinic.Models.Doctor", "class_clinic_1_1_models_1_1_doctor.html", null ],
    [ "Clinic.ViewModels.Clinic.DoctorsViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model.html", null ],
    [ "Clinic.ViewModels.ErrorViewModel", "class_clinic_1_1_view_models_1_1_error_view_model.html", null ],
    [ "Clinic.Services.Interfaces.IAccountService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service.html", [
      [ "Clinic.Services.AccountService", "class_clinic_1_1_services_1_1_account_service.html", null ]
    ] ],
    [ "Clinic.Services.Interfaces.IClinicService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html", [
      [ "Clinic.Services.ClinicService", "class_clinic_1_1_services_1_1_clinic_service.html", null ]
    ] ],
    [ "IdentityDbContext", null, [
      [ "Clinic.Data.ApplicationDbContext", "class_clinic_1_1_data_1_1_application_db_context.html", null ]
    ] ],
    [ "IdentityRole", null, [
      [ "Clinic.Models.AppRole", "class_clinic_1_1_models_1_1_app_role.html", null ]
    ] ],
    [ "IdentityUser", null, [
      [ "Clinic.Models.AppUser", "class_clinic_1_1_models_1_1_app_user.html", null ]
    ] ],
    [ "Clinic.Services.Interfaces.IHomeService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_home_service.html", [
      [ "Clinic.Services.HomeService", "class_clinic_1_1_services_1_1_home_service.html", null ]
    ] ],
    [ "Clinic.Repositories.Interfaces.IUserRepository", "interface_clinic_1_1_repositories_1_1_interfaces_1_1_i_user_repository.html", [
      [ "Clinic.Repositories.UserRepository", "class_clinic_1_1_repositories_1_1_user_repository.html", null ]
    ] ],
    [ "Clinic.ViewModels.Account.LoginViewModel", "class_clinic_1_1_view_models_1_1_account_1_1_login_view_model.html", null ],
    [ "Migration", null, [
      [ "Clinic.Migrations.init", "class_clinic_1_1_migrations_1_1init.html", null ]
    ] ],
    [ "ModelSnapshot", null, [
      [ "Clinic.Migrations.ApplicationDbContextModelSnapshot", "class_clinic_1_1_migrations_1_1_application_db_context_model_snapshot.html", null ]
    ] ],
    [ "Clinic.ViewModels.Home.MyVisitsViewModel", "class_clinic_1_1_view_models_1_1_home_1_1_my_visits_view_model.html", null ],
    [ "Clinic.Program", "class_clinic_1_1_program.html", null ],
    [ "Clinic.ViewModels.Account.RegisterViewModel", "class_clinic_1_1_view_models_1_1_account_1_1_register_view_model.html", null ],
    [ "Clinic.Services.ServiceResponses.ServiceResponse< T >", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html", null ],
    [ "Clinic.Models.Specialization", "class_clinic_1_1_models_1_1_specialization.html", null ],
    [ "Clinic.Startup", "class_clinic_1_1_startup.html", null ],
    [ "Clinic.Models.Visit", "class_clinic_1_1_models_1_1_visit.html", null ],
    [ "Clinic.ViewModels.Clinic.VisitsViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model.html", null ],
    [ "Clinic.WebHostExtensions", "class_clinic_1_1_web_host_extensions.html", null ]
];