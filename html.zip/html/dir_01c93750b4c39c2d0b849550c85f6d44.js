var dir_01c93750b4c39c2d0b849550c85f6d44 =
[
    [ "Interfaces", "dir_75bb92bf26eaa4a815ef6de47ab07e4c.html", "dir_75bb92bf26eaa4a815ef6de47ab07e4c" ],
    [ "UserRepository.cs", "_user_repository_8cs.html", [
      [ "UserRepository", "class_clinic_1_1_repositories_1_1_user_repository.html", "class_clinic_1_1_repositories_1_1_user_repository" ]
    ] ]
];