var class_clinic_1_1_models_1_1_visit =
[
    [ "Doctor", "class_clinic_1_1_models_1_1_visit.html#a7e700e9aa025872e89714a58e6cc98f3", null ],
    [ "DoctorId", "class_clinic_1_1_models_1_1_visit.html#ab3e3984234964ea61552f72c9b25dec9", null ],
    [ "Id", "class_clinic_1_1_models_1_1_visit.html#aa3cdba79577f34c4c671b9db781f3f72", null ],
    [ "Patient", "class_clinic_1_1_models_1_1_visit.html#a1f3b3bd2fa00643429d6c9af2a9218e9", null ],
    [ "PatientId", "class_clinic_1_1_models_1_1_visit.html#a198f6d36d4f85b3e54b51eb6ebccc2ab", null ],
    [ "Time", "class_clinic_1_1_models_1_1_visit.html#a5039b6a34eb9146aee7355134875d08c", null ]
];