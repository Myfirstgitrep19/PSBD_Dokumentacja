var class_clinic_1_1_models_1_1_specialization =
[
    [ "Id", "class_clinic_1_1_models_1_1_specialization.html#a5912e4690e6bb1f670de3483e18871a1", null ],
    [ "Name", "class_clinic_1_1_models_1_1_specialization.html#aebd4679c4cf36c7367b8bf252e5e1188", null ]
];