var namespace_clinic_1_1_data =
[
    [ "ApplicationDbContext", "class_clinic_1_1_data_1_1_application_db_context.html", "class_clinic_1_1_data_1_1_application_db_context" ],
    [ "DataInitialization", "class_clinic_1_1_data_1_1_data_initialization.html", "class_clinic_1_1_data_1_1_data_initialization" ]
];