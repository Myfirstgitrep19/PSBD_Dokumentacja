var dir_fc0e8ce851d32c7f265ae9813e1d230d =
[
    [ "IAccountService.cs", "_i_account_service_8cs.html", [
      [ "IAccountService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service.html", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service" ]
    ] ],
    [ "IClinicService.cs", "_i_clinic_service_8cs.html", [
      [ "IClinicService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service" ]
    ] ],
    [ "IHomeService.cs", "_i_home_service_8cs.html", [
      [ "IHomeService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_home_service.html", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_home_service" ]
    ] ]
];