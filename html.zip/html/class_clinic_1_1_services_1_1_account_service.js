var class_clinic_1_1_services_1_1_account_service =
[
    [ "AccountService", "class_clinic_1_1_services_1_1_account_service.html#a0fd48f88d7a7214f5bde1505fbb65638", null ],
    [ "Login", "class_clinic_1_1_services_1_1_account_service.html#a094899417994d7058246e2e0ce109e9a", null ],
    [ "Logout", "class_clinic_1_1_services_1_1_account_service.html#a501fbf1fe25088f14d4c9259bfbe87ee", null ],
    [ "RegisterNewUser", "class_clinic_1_1_services_1_1_account_service.html#a68eb59b74d225aa38a929b9ff0531766", null ],
    [ "SignInManager", "class_clinic_1_1_services_1_1_account_service.html#aa359cb8b58a7f38001b11e9fef1d79c6", null ],
    [ "UserManager", "class_clinic_1_1_services_1_1_account_service.html#a4a6f695d8a440dd6614218058dc3e9d9", null ]
];