var namespace_clinic_1_1_view_models_1_1_account =
[
    [ "LoginViewModel", "class_clinic_1_1_view_models_1_1_account_1_1_login_view_model.html", "class_clinic_1_1_view_models_1_1_account_1_1_login_view_model" ],
    [ "RegisterViewModel", "class_clinic_1_1_view_models_1_1_account_1_1_register_view_model.html", "class_clinic_1_1_view_models_1_1_account_1_1_register_view_model" ]
];