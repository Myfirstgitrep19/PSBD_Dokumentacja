var class_clinic_1_1_services_1_1_home_service =
[
    [ "HomeService", "class_clinic_1_1_services_1_1_home_service.html#ac7ea90721967f5f9a59d7c7b671fb937", null ],
    [ "GetMyVisitsViewModel", "class_clinic_1_1_services_1_1_home_service.html#abf67a469216de1503e0a4f1d19faea90", null ]
];