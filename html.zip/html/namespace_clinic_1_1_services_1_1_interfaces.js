var namespace_clinic_1_1_services_1_1_interfaces =
[
    [ "IAccountService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service.html", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service" ],
    [ "IClinicService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service" ],
    [ "IHomeService", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_home_service.html", "interface_clinic_1_1_services_1_1_interfaces_1_1_i_home_service" ]
];