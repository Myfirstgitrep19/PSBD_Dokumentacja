var dir_f434ba72540700a58a186a8a1803d3f7 =
[
    [ "ApplicationDbContext.cs", "_application_db_context_8cs.html", [
      [ "ApplicationDbContext", "class_clinic_1_1_data_1_1_application_db_context.html", "class_clinic_1_1_data_1_1_application_db_context" ]
    ] ],
    [ "DataInitialization.cs", "_data_initialization_8cs.html", [
      [ "DataInitialization", "class_clinic_1_1_data_1_1_data_initialization.html", "class_clinic_1_1_data_1_1_data_initialization" ]
    ] ]
];