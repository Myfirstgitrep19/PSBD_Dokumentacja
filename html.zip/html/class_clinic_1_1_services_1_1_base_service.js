var class_clinic_1_1_services_1_1_base_service =
[
    [ "BaseService", "class_clinic_1_1_services_1_1_base_service.html#affe9c22cd28b590a8f939784dba80849", null ],
    [ "Context", "class_clinic_1_1_services_1_1_base_service.html#a979cb4cb6f9e7f9b2c43a163ecbcb779", null ],
    [ "Logger", "class_clinic_1_1_services_1_1_base_service.html#a1ffc090c2adc9f67ba6e71ddd30c7ea3", null ]
];