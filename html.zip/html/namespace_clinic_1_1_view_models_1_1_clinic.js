var namespace_clinic_1_1_view_models_1_1_clinic =
[
    [ "ClinicIndexViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_clinic_index_view_model.html", "class_clinic_1_1_view_models_1_1_clinic_1_1_clinic_index_view_model" ],
    [ "DoctorsViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model.html", "class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model" ],
    [ "VisitsViewModel", "class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model.html", "class_clinic_1_1_view_models_1_1_clinic_1_1_visits_view_model" ]
];