var dir_1ce68f9c1d80319a1a2aa380e7eef7c4 =
[
    [ "LoginViewModel.cs", "_login_view_model_8cs.html", [
      [ "LoginViewModel", "class_clinic_1_1_view_models_1_1_account_1_1_login_view_model.html", "class_clinic_1_1_view_models_1_1_account_1_1_login_view_model" ]
    ] ],
    [ "RegisterViewModel.cs", "_register_view_model_8cs.html", [
      [ "RegisterViewModel", "class_clinic_1_1_view_models_1_1_account_1_1_register_view_model.html", "class_clinic_1_1_view_models_1_1_account_1_1_register_view_model" ]
    ] ]
];