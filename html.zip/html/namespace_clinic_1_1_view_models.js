var namespace_clinic_1_1_view_models =
[
    [ "Account", "namespace_clinic_1_1_view_models_1_1_account.html", "namespace_clinic_1_1_view_models_1_1_account" ],
    [ "Clinic", "namespace_clinic_1_1_view_models_1_1_clinic.html", "namespace_clinic_1_1_view_models_1_1_clinic" ],
    [ "Home", "namespace_clinic_1_1_view_models_1_1_home.html", "namespace_clinic_1_1_view_models_1_1_home" ],
    [ "ErrorViewModel", "class_clinic_1_1_view_models_1_1_error_view_model.html", "class_clinic_1_1_view_models_1_1_error_view_model" ]
];