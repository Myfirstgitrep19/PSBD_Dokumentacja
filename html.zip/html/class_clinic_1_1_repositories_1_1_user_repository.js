var class_clinic_1_1_repositories_1_1_user_repository =
[
    [ "UserRepository", "class_clinic_1_1_repositories_1_1_user_repository.html#a2d5bfe2286cb4d5be3bfd70c222cde85", null ],
    [ "GetUserById", "class_clinic_1_1_repositories_1_1_user_repository.html#a47a5a7008c79bf7fbdeca0783a16278e", null ],
    [ "Context", "class_clinic_1_1_repositories_1_1_user_repository.html#a2efcc552d8f63b9324cadb94e12767e3", null ]
];