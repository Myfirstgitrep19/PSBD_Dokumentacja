var class_clinic_1_1_controllers_1_1_clinic_controller =
[
    [ "ClinicController", "class_clinic_1_1_controllers_1_1_clinic_controller.html#a0f85c8ad8b4e48fac53d51a310b03aa8", null ],
    [ "DeleteVisit", "class_clinic_1_1_controllers_1_1_clinic_controller.html#ad2190414262b48d4c38f49f08af301bb", null ],
    [ "Doctors", "class_clinic_1_1_controllers_1_1_clinic_controller.html#ace21087eb3ad8361c70e22eb53c35a0f", null ],
    [ "Index", "class_clinic_1_1_controllers_1_1_clinic_controller.html#a1b8d90d1fc0a4f62e14a8b2fefa1a475", null ],
    [ "Visits", "class_clinic_1_1_controllers_1_1_clinic_controller.html#aa10ccf50e8cd2266b45d184316a1ff92", null ],
    [ "Visits", "class_clinic_1_1_controllers_1_1_clinic_controller.html#af2cd6c2d7f0d3c4f236bd6fbf544385a", null ],
    [ "_clinicService", "class_clinic_1_1_controllers_1_1_clinic_controller.html#a09fa9e9fb858b6391a5c2fea826ecf48", null ]
];