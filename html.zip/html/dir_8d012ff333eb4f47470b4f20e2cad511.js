var dir_8d012ff333eb4f47470b4f20e2cad511 =
[
    [ "Clinic", "dir_3c2d042c98e0a7dcb0ea47adc99096b9.html", "dir_3c2d042c98e0a7dcb0ea47adc99096b9" ]
];