var dir_dcfd38993d178f2b10963fe9b6cdc692 =
[
    [ "ServiceResponse.cs", "_service_response_8cs.html", [
      [ "ServiceResponse", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html", "class_clinic_1_1_services_1_1_service_responses_1_1_service_response" ]
    ] ]
];