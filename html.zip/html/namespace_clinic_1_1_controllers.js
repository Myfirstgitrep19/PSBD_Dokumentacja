var namespace_clinic_1_1_controllers =
[
    [ "AccountController", "class_clinic_1_1_controllers_1_1_account_controller.html", "class_clinic_1_1_controllers_1_1_account_controller" ],
    [ "BaseController", "class_clinic_1_1_controllers_1_1_base_controller.html", "class_clinic_1_1_controllers_1_1_base_controller" ],
    [ "ClinicController", "class_clinic_1_1_controllers_1_1_clinic_controller.html", "class_clinic_1_1_controllers_1_1_clinic_controller" ],
    [ "HomeController", "class_clinic_1_1_controllers_1_1_home_controller.html", "class_clinic_1_1_controllers_1_1_home_controller" ]
];