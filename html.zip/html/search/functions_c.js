var searchData=
[
  ['privacy_309',['Privacy',['../class_clinic_1_1_controllers_1_1_home_controller.html#afd08a8155170fad68bed34a59977765a',1,'Clinic::Controllers::HomeController']]]
];
