var searchData=
[
  ['name_383',['Name',['../class_clinic_1_1_models_1_1_clinic.html#acda962ebac1ba1bb961f33046d75c50a',1,'Clinic.Models.Clinic.Name()'],['../class_clinic_1_1_models_1_1_doctor.html#afda6fc2027ae3856c0dea463025c5f7c',1,'Clinic.Models.Doctor.Name()'],['../class_clinic_1_1_models_1_1_specialization.html#aebd4679c4cf36c7367b8bf252e5e1188',1,'Clinic.Models.Specialization.Name()']]]
];
