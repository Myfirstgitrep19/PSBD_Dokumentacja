var searchData=
[
  ['userrepository_2ecs_269',['UserRepository.cs',['../_user_repository_8cs.html',1,'']]]
];
