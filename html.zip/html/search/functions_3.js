var searchData=
[
  ['datainitialization_287',['DataInitialization',['../class_clinic_1_1_data_1_1_data_initialization.html#a47971f2cfeba2bd37a69b82b6eccce12',1,'Clinic::Data::DataInitialization']]],
  ['deletevisit_288',['DeleteVisit',['../class_clinic_1_1_controllers_1_1_clinic_controller.html#ad2190414262b48d4c38f49f08af301bb',1,'Clinic.Controllers.ClinicController.DeleteVisit()'],['../class_clinic_1_1_services_1_1_clinic_service.html#ada632348848a9f02976474dd545bc4bd',1,'Clinic.Services.ClinicService.DeleteVisit()'],['../interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html#a243b5ef6b67b6aeced1ed6d5a9045f0e',1,'Clinic.Services.Interfaces.IClinicService.DeleteVisit()']]],
  ['doctors_289',['Doctors',['../class_clinic_1_1_controllers_1_1_clinic_controller.html#ace21087eb3ad8361c70e22eb53c35a0f',1,'Clinic::Controllers::ClinicController']]],
  ['down_290',['Down',['../class_clinic_1_1_migrations_1_1init.html#a9a73038239d67fbe2bdbd16d9e1e4217',1,'Clinic::Migrations::init']]]
];
