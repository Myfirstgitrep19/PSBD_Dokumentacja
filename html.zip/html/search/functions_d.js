var searchData=
[
  ['register_310',['Register',['../class_clinic_1_1_controllers_1_1_account_controller.html#a5cc8c90859ae3681523da9b3663cf3fe',1,'Clinic.Controllers.AccountController.Register()'],['../class_clinic_1_1_controllers_1_1_account_controller.html#a7ab7be20f5f5e42278a7b13384e41c7a',1,'Clinic.Controllers.AccountController.Register(RegisterViewModel model)']]],
  ['registernewuser_311',['RegisterNewUser',['../class_clinic_1_1_services_1_1_account_service.html#a68eb59b74d225aa38a929b9ff0531766',1,'Clinic.Services.AccountService.RegisterNewUser()'],['../interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service.html#a152fcc4e6dca0974c32dd0f6abbbf563',1,'Clinic.Services.Interfaces.IAccountService.RegisterNewUser()']]]
];
