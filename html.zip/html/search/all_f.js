var searchData=
[
  ['ok_134',['Ok',['../class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a1404eb72e0c2aa939afb50ae5421818c',1,'Clinic.Services.ServiceResponses.ServiceResponse.Ok(bool data=true, string message=&quot;&quot;)'],['../class_clinic_1_1_services_1_1_service_responses_1_1_service_response.html#a4dc546c7ef1d3bd805aab5d8399d535b',1,'Clinic.Services.ServiceResponses.ServiceResponse.Ok(T data, string message=&quot;&quot;)']]],
  ['onmodelcreating_135',['OnModelCreating',['../class_clinic_1_1_data_1_1_application_db_context.html#a14131764165ab8ef2bb1c5091629b1bb',1,'Clinic::Data::ApplicationDbContext']]],
  ['otherwise_136',['OTHERWISE',['../jquery_2_l_i_c_e_n_s_e_8txt.html#ab3867aff7d9b83ce1513d111cce6a50d',1,'LICENSE.txt']]]
];
