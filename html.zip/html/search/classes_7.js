var searchData=
[
  ['loginviewmodel_212',['LoginViewModel',['../class_clinic_1_1_view_models_1_1_account_1_1_login_view_model.html',1,'Clinic::ViewModels::Account']]]
];
