var searchData=
[
  ['version_321',['Version',['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#ab275d752056b1eb94e5942a9a32babda',1,'LICENSE.txt']]],
  ['visits_322',['Visits',['../class_clinic_1_1_controllers_1_1_clinic_controller.html#aa10ccf50e8cd2266b45d184316a1ff92',1,'Clinic.Controllers.ClinicController.Visits(int doctorId)'],['../class_clinic_1_1_controllers_1_1_clinic_controller.html#af2cd6c2d7f0d3c4f236bd6fbf544385a',1,'Clinic.Controllers.ClinicController.Visits(VisitsViewModel model)']]]
];
