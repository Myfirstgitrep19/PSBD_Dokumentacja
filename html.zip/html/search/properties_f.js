var searchData=
[
  ['visits_396',['Visits',['../class_clinic_1_1_data_1_1_application_db_context.html#aba1c87b9401c17fc7e530d1915565ab3',1,'Clinic.Data.ApplicationDbContext.Visits()'],['../class_clinic_1_1_view_models_1_1_home_1_1_my_visits_view_model.html#a1a4f089ca5432bf3e0df3962d536b0f4',1,'Clinic.ViewModels.Home.MyVisitsViewModel.Visits()']]]
];
