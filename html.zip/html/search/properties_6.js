var searchData=
[
  ['id_380',['Id',['../class_clinic_1_1_models_1_1_address.html#a8845b38fce0281020a466c8cc63da2ac',1,'Clinic.Models.Address.Id()'],['../class_clinic_1_1_models_1_1_clinic.html#a1b76f9bcc8265df9b5aabc2e2b8d9877',1,'Clinic.Models.Clinic.Id()'],['../class_clinic_1_1_models_1_1_doctor.html#a06243832ca87a300be98cb4f3d76e1bf',1,'Clinic.Models.Doctor.Id()'],['../class_clinic_1_1_models_1_1_specialization.html#a5912e4690e6bb1f670de3483e18871a1',1,'Clinic.Models.Specialization.Id()'],['../class_clinic_1_1_models_1_1_visit.html#aa3cdba79577f34c4c671b9db781f3f72',1,'Clinic.Models.Visit.Id()']]]
];
