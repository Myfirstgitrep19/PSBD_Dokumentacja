var searchData=
[
  ['20200527211632_5finit_2ecs_235',['20200527211632_init.cs',['../20200527211632__init_8cs.html',1,'']]],
  ['20200527211632_5finit_2edesigner_2ecs_236',['20200527211632_init.Designer.cs',['../20200527211632__init_8_designer_8cs.html',1,'']]]
];
