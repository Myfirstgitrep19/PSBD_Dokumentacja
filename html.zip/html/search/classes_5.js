var searchData=
[
  ['homecontroller_205',['HomeController',['../class_clinic_1_1_controllers_1_1_home_controller.html',1,'Clinic::Controllers']]],
  ['homeservice_206',['HomeService',['../class_clinic_1_1_services_1_1_home_service.html',1,'Clinic::Services']]]
];
