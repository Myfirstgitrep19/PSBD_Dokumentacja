var searchData=
[
  ['kind_115',['KIND',['../jquery_2_l_i_c_e_n_s_e_8txt.html#ab32eaa76edf5a371670da2291d1bc1ef',1,'KIND():&#160;LICENSE.txt'],['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#ae682d8dbab53b032858b0f40d1a05c4d',1,'KIND():&#160;LICENSE.txt']]]
];
