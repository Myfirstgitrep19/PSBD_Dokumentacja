var searchData=
[
  ['up_319',['Up',['../class_clinic_1_1_migrations_1_1init.html#a237658b709b805067797ec7df31db286',1,'Clinic::Migrations::init']]],
  ['userrepository_320',['UserRepository',['../class_clinic_1_1_repositories_1_1_user_repository.html#a2d5bfe2286cb4d5be3bfd70c222cde85',1,'Clinic::Repositories::UserRepository']]]
];
