var searchData=
[
  ['iaccountservice_103',['IAccountService',['../interface_clinic_1_1_services_1_1_interfaces_1_1_i_account_service.html',1,'Clinic::Services::Interfaces']]],
  ['iaccountservice_2ecs_104',['IAccountService.cs',['../_i_account_service_8cs.html',1,'']]],
  ['iclinicservice_105',['IClinicService',['../interface_clinic_1_1_services_1_1_interfaces_1_1_i_clinic_service.html',1,'Clinic::Services::Interfaces']]],
  ['iclinicservice_2ecs_106',['IClinicService.cs',['../_i_clinic_service_8cs.html',1,'']]],
  ['id_107',['Id',['../class_clinic_1_1_models_1_1_address.html#a8845b38fce0281020a466c8cc63da2ac',1,'Clinic.Models.Address.Id()'],['../class_clinic_1_1_models_1_1_clinic.html#a1b76f9bcc8265df9b5aabc2e2b8d9877',1,'Clinic.Models.Clinic.Id()'],['../class_clinic_1_1_models_1_1_doctor.html#a06243832ca87a300be98cb4f3d76e1bf',1,'Clinic.Models.Doctor.Id()'],['../class_clinic_1_1_models_1_1_specialization.html#a5912e4690e6bb1f670de3483e18871a1',1,'Clinic.Models.Specialization.Id()'],['../class_clinic_1_1_models_1_1_visit.html#aa3cdba79577f34c4c671b9db781f3f72',1,'Clinic.Models.Visit.Id()']]],
  ['ihomeservice_108',['IHomeService',['../interface_clinic_1_1_services_1_1_interfaces_1_1_i_home_service.html',1,'Clinic::Services::Interfaces']]],
  ['ihomeservice_2ecs_109',['IHomeService.cs',['../_i_home_service_8cs.html',1,'']]],
  ['implied_110',['IMPLIED',['../jquery_2_l_i_c_e_n_s_e_8txt.html#ac2ec4382668e57df3d93992f0ffc0c18',1,'LICENSE.txt']]],
  ['index_111',['Index',['../class_clinic_1_1_controllers_1_1_clinic_controller.html#a1b8d90d1fc0a4f62e14a8b2fefa1a475',1,'Clinic.Controllers.ClinicController.Index()'],['../class_clinic_1_1_controllers_1_1_home_controller.html#afd3fe97be6bff272ef23def30c6646f0',1,'Clinic.Controllers.HomeController.Index()']]],
  ['init_112',['init',['../class_clinic_1_1_migrations_1_1init.html',1,'Clinic::Migrations']]],
  ['iuserrepository_113',['IUserRepository',['../interface_clinic_1_1_repositories_1_1_interfaces_1_1_i_user_repository.html',1,'Clinic::Repositories::Interfaces']]],
  ['iuserrepository_2ecs_114',['IUserRepository.cs',['../_i_user_repository_8cs.html',1,'']]]
];
