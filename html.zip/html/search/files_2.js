var searchData=
[
  ['basecontroller_2ecs_244',['BaseController.cs',['../_base_controller_8cs.html',1,'']]],
  ['baseservice_2ecs_245',['BaseService.cs',['../_base_service_8cs.html',1,'']]]
];
