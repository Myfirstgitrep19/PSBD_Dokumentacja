var class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model =
[
    [ "Doctors", "class_clinic_1_1_view_models_1_1_clinic_1_1_doctors_view_model.html#af6799a68a776beefb796cfe49ad42fa4", null ]
];