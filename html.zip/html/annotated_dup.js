var annotated_dup =
[
    [ "Clinic", "namespace_clinic.html", "namespace_clinic" ]
];