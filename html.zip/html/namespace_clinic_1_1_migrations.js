var namespace_clinic_1_1_migrations =
[
    [ "ApplicationDbContextModelSnapshot", "class_clinic_1_1_migrations_1_1_application_db_context_model_snapshot.html", "class_clinic_1_1_migrations_1_1_application_db_context_model_snapshot" ],
    [ "init", "class_clinic_1_1_migrations_1_1init.html", "class_clinic_1_1_migrations_1_1init" ]
];